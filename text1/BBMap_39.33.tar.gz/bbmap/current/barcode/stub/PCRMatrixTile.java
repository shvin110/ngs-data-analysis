package barcode.stub;

/**
 * @author Brian Bushnell
 * @date March 25, 2024
 *
 */
public class PCRMatrixTile extends PCRMatrixProbAbstract {
	
	public PCRMatrixTile(int a, int b, int c, boolean d) {}
	
}
